//
//  PTImageIODataSaveManager.h
//  OpenSaveDemo
//
//  Created by Rimas Mickevičius on 2013-01-09.
//  Copyright (c) 2013 Rimas Mickevičius. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "PTImageIOProtocols.h"
#import "PTImageIODefinitions.h"

#import <Accelerate/Accelerate.h>

extern NSString *const PTImageIOAdditionalThumbnailProcessingInfoKey;
extern NSString *const PTImageIOAdditionalThumbnailPathSubKey;
extern NSString *const PTImageIOAdditionalThumbnailSizeSubKey;
extern NSString *const PTImageIOAdditionalThumbnailScaleSubKey;

// DOCUMENT
extern NSString *const PTImageIOFormatDocumentIDInfoKey;
extern NSString *const PTImageIOFormatDocumentSizeInfoKey;
extern NSString *const PTImageIOFormatDocumentResolutionSizeInfoKey;
extern NSString *const PTImageIOFormatDocumentResolutionUnitsInfoKey;
extern NSString *const PTImageIOFormatDocumentBitsPerComponentInfoKey;
extern NSString *const PTImageIOFormatDocumentNumberOfComponentsInfoKey;
extern NSString *const PTImageIOFormatDocumentBitmapDataFormatInfoKey;
extern NSString *const PTImageIOFormatDocumentColorsyncProfileInfoKey;
extern NSString *const PTImageIOFormatDocumentCustomDataInfoKey;
extern NSString *const PTImageIOFormatDocumentVisibleRectInfoKey;
extern NSString *const PTImageIOFormatDocumentGuidesInfoKey;
extern NSString *const PTImageIOFormatDocumentViewZoomInfoKey;
extern NSString *const PTImageIOFormatDocumentKeywordsInfoKey;
extern NSString *const PTImageIOFormatDocumentLayersLinkingInfoKey;
extern NSString *const PTImageIOFormatDocumentSaveDateInfoKey;
extern NSString *const PTImageIOFormatDocumentFileVersionInfoKey;
extern NSString *const PTImageIOFormatDocumentFileVersionSupportInfoKey;
extern NSString *const PTImageIOFormatDocumentSavedWithAppVersionInfoKey;
extern NSString *const PTImageIOFormatDocumentSavedOnPlatformInfoKey;
extern NSString *const PTImageIOFormatDocumentRequiresMinimumAppVersionInfoKey;
extern NSString *const PTImageIOFormatDocumentVersionInfoKey;

extern NSString *const PTImageIOFormatDocumentOriginalExifDictionaryInfoKey;
extern NSString *const PTImageIOFormatDocumentBasicMetadataInfoKey;             //

extern NSString *const PTImageIOFormatBasicMetaDocumentSizeInfoKey;
extern NSString *const PTImageIOFormatBasicMetaNumberOfComponentsInfoKey;
extern NSString *const PTImageIOFormatBasicMetaBitsPerComponentInfoInfoKey;
extern NSString *const PTImageIOFormatBasicMetaColorspaceModelInfoKey;
extern NSString *const PTImageIOFormatBasicMetaColorspaceNameInfoKey;
extern NSString *const PTImageIOFormatBasicMetaKeywordsInfoKey;
extern NSString *const PTImageIOFormatBasicMetaLayerNamesInfoKey;
extern NSString *const PTImageIOFormatBasicMetaResolutionInfoKey;
extern NSString *const PTImageIOFormatBasicMetaResolutionUnitsInfoKey;
extern NSString *const PTImageIOFormatBasicMetaVersionInfoKey;
extern NSString *const PTImageIOFormatBasicMetaDataAmountInfoKey;
extern NSString *const PTImageIOFormatBasicMetaLayersCounttInfoKey;


extern NSString *const PTImageIOPlatformMacOS;
extern NSString *const PTImageIOPlatformiOS;

// REQUIRED
extern NSString *const PTImageIOFormatLayerHasBitmapDataInfoKey;
extern NSString *const PTImageIOFormatLayerBitmapDataChangeTimestampInfoKey;
// OPTIONAL
extern NSString *const PTImageIOFormatLayerNameInfoKey;
extern NSString *const PTImageIOFormatLayerIsVisibleInfoKey;
extern NSString *const PTImageIOFormatLayerOriginInfoKey;
extern NSString *const PTImageIOFormatLayerSizeInfoKey;
extern NSString *const PTImageIOFormatLayerOpacityInfoKey;
extern NSString *const PTImageIOFormatLayerBlendingModeInfoKey;
extern NSString *const PTImageIOFormatLayerIsClippingMaskInfoKey;
extern NSString *const PTImageIOFormatLayerPreservesTransparencyInfoKey;
extern NSString *const PTImageIOFormatLayerSpecificDataInfoKey;
extern NSString *const PTImageIOFormatLayerBitmapDataRowBytesInfoKey;
extern NSString *const PTImageIOFormatLayerMaskEdgeTypeInfoKey;
extern NSString *const PTImageIOFormatLayerParentIsLinkedWithMaskInfoKey;
extern NSString *const PTImageIOFormatLayerParentIsEditingMaskInfoKey;
extern NSString *const PTImageIOFormatLayerBitmapDataFormatInfoKey;

extern NSString *const PTImageIOFormatLayerDoNotAllocateBufferInfoKey;
extern NSString *const PTImageIOFormatLayerBitmapDataInfoKey;
extern NSString *const PTImageIOFormatLayerPhotoshopTextInfoKey;

// format specific
extern NSString *const PTImageIOFormatSpecificLayerMaskIDInfoKey;
extern NSString *const PTImageIOFormatSpecificTextLayerTextInfoKey;
extern NSString *const PTImageIOFormatSpecificTextLayerRotationInfoKey;
extern NSString *const PTImageIOFormatSpecificTextLayerTopLeftPointInfoKey;
extern NSString *const PTImageIOFormatSpecificTextLayerRectInfoKey;
extern NSString *const PTImageIOFormatSpecificTextLayerVerticalOffsetInfoKey;
extern NSString *const PTImageIOFormatSpecificTextLayerOneLineSizeInfoKey;
extern NSString *const PTImageIOFormatSpecificTextLayerTextStorageInfoKey;
extern NSString *const PTImageIOFormatSpecificTextLayerTypeInfoKey;
extern NSString *const PTImageIOFormatSpecificGroupExpandedInfoKey;
extern NSString *const PTImageIOFormatSpecificTextLayerRasterizedSizeInfoKey;
extern NSString *const PTImageIOFormatSpecificTextLayerRasterizedOriginInfoKey;

enum {
    PTImageIOThumbnailDoNotScaleOption = 0,
    PTImageIOThumbnailDownScaleOnlyOption,
    PTImageIOThumbnailAlwaysScaleOption,
};
typedef NSInteger PTImageIOThumbnailScaleOption;


enum {
    PTImageIOThumbnailPNGType = 0,
};
typedef NSInteger PTImageIOThumbnailType;



@interface PTImageIODataOperationContext : NSObject
@end

@interface PTImageIODataWriteContext : PTImageIODataOperationContext
{
    NSURL               *_destinationURL;
    NSString            *_typeUTI;
    PTSaveOperation     _saveOperation;
    NSURL               *_originalContentURL;
    NSDictionary        *_options;
    NSMutableDictionary *g_outputOptionsDictionary;
    
    BOOL                _dataProviderShouldBeUnblockedWhenPossible;
    BOOL                _dataProviderWasUnblocked; // FIXME: early unblocking in non pxm writing
    CGFloat             _normalizedWriteQuality;
    BOOL                _isExportOperation;
    NSURL               *_urlOfTemporaryFileToUse;
    BOOL                _shouldStripColorSyncProfile;
    id                  _preferedDataProviderSource;
    NSData              *_prerenderedImageARGBData;
    CGSize              _prerenderedImageSize;
    NSInteger           _prerenderedImageRowBytes;
    
    CGImageRef          g_cachedPreviewImage;
    
    NSMutableDictionary *g_layerBuffersCopies;
    dispatch_queue_t    g_layerBufferCopiesAcessConcurentQueue;
}
+ (PTImageIODataWriteContext *)contextForWritingAtURL:(NSURL *)destinationURL ofType:(NSString *)typeUTI forSaveOperation:(PTSaveOperation)operation originalContentsURL:(NSURL *)originalContentURL options:(NSDictionary *)options;
@property (readonly, copy)  NSURL           *destinationURL;
@property (readonly, copy)  NSString        *typeUTI;
@property (readonly)        PTSaveOperation saveOperation;
@property (readonly, copy)  NSURL           *originalContentURL;
@property (readonly, copy)  NSDictionary    *options;
- (NSMutableDictionary *)outputOptions;

@property                       BOOL            dataProviderShouldBeUnblockedWhenPossible;
@property                       BOOL            dataProviderWasUnblocked;
@property                       CGFloat         normalizedWriteQuality;
@property                       BOOL            isExportOperation;
@property (copy)                NSURL           *urlOfTemporaryFileToUse;
@property                       BOOL            shouldStripColorSyncProfile;
@property (retain)              id              preferedDataProviderSource;
@property (retain)              NSData          *prerenderedImageARGBData;
@property                       CGSize          prerenderedImageSize;
@property                       NSInteger       prerenderedImageRowByttes;

- (void)setCachedPreviewImage:(CGImageRef)newImage;
- (CGImageRef)cachedPreviewImage;

// on 10.7 and later those 4 methods are thread-safe
- (void)setLayerBufferCopiesObject:(id)anObject forKey:(NSString *)key;
- (id)getLayerBufferCopiesObjectForKey:(NSString *)key;
- (void)removeLayerBufferCopiesObjectForKey:(NSString *)key;
- (void)removeAllObjectsFromLayerBufferCopies;

@end


@interface PTImageIODataReadContext : PTImageIODataOperationContext
{
    NSURL                               *_sourceURL;
    NSString                            *_typeUTI;
    NSDictionary                        *_options;
    PTImageIOActivityProgressProvider   _readingProgressCallbackBlock;
    BOOL                                _openedFileMustBeImported;
    
    NSMutableDictionary                 *g_outputOptionsDictionary;
    CGColorSpaceRef                     g_destinationColorSpace;
    BOOL                                _useCustomDestinationColorSpace;
    BOOL                                _imageConvertedToRGBuponOpening;
    BOOL                                _shouldFixOrientationUponOpening;
    uint8_t                             _originalImageBitsPerComponent;
    NSArray                             *_supportedBitsPerComponent;
    
    
    vImage_Buffer                       g_previewImageBuffer;
    CGImageRef                          g_previewImageRef;
    BOOL                                _shouldCreatePreviewCGImage;
    BOOL                                _shouldCreatePreviewBuffer;
    NSDictionary                        *_previewImagePropertiesDictionary;
    NSData                              *_inputImageContentData;
}

+ (PTImageIODataReadContext *)contextForReadingFromURL:(NSURL *)sourceURL ofType:(NSString *)typeUTI options:(NSDictionary *)options;
+ (PTImageIODataReadContext *)contextForReadingData:(NSData *)imageData options:(NSDictionary *)options;
@property (readonly,    copy)   NSURL                               *sourceURL;
@property (readonly,    copy)   NSString                            *typeUTI;
@property (readonly,    copy)   NSDictionary                        *options;
@property (readwrite,   copy)   PTImageIOActivityProgressProvider   readingProgressCallbackBlock;
@property (readwrite)           BOOL                                openedFileMustBeImported;

- (NSMutableDictionary *)outputOptions;
// don't touch this unless you know, what are you doing - even calling it with NULL will make useCustomDestinationColorSpace to return YES
- (void)setDestinationColorSpace:(CGColorSpaceRef)destColorSpace;
- (CGColorSpaceRef)destinationColorSpace;
@property (readonly)            BOOL                                useCustomDestinationColorSpace;
@property (readwrite)           BOOL                                imageConvertedToRGBuponOpening;
@property (readwrite)           BOOL                                shouldFixOrientationUponOpening;
@property (readwrite)           uint8_t                             originalImageBitsPerComponent;
@property (readwrite, copy)     NSArray                             *supportedBitsPerComponent;

// those two things will be realesed on dealloc. So to keep CGImage you must retain it, and to keep buffer, you mast keep pointer by yourself and set pointerToPreviewImageBuffer->data to NULL;
- (vImage_Buffer *)pointerToPreviewImageBuffer;

- (void)setPreviewImageRef:(CGImageRef *)previewImageRefPointer;
- (CGImageRef)previewImage;
@property (readwrite)           BOOL                                shouldCreatePreviewCGImage;
@property (readwrite)           BOOL                                shouldCreatePreviewBuffer;
@property (readwrite, copy)     NSDictionary                        *previewImagePropertiesDictionary;
@property (readwrite, retain)   NSData                              *inputImageContentData;

@end







@interface PTImageIODataSaveManager : NSObject
{
    NSString    *_associatedID;
    NSURL       *_managerCacheFolderURL;
    
    NSMutableDictionary *g_layersDataCacheInfoByLayerID;
    dispatch_queue_t    g_layerDataCacheInfoAccessQueue;
}

@property (readwrite, copy) NSString    *associatedID;
@property (readwrite, copy) NSURL       *managerCacheFolderURL;

+ (BOOL)canReadFileAtURL:(NSURL *)fileURL;
+ (BOOL)canReadFileWithUTI:(NSString *)fileUTI;



+ (BOOL)writeCurrentStateOf:(id<PTImageIODataStateInfoProviderProtocol>)dataProvider usingContext:(PTImageIODataWriteContext *)writeContext error:(NSError **)outError;

+ (BOOL)readFileDataInto:(id<PTImageIOFileDataOpenInfoConsumer>)dataConsumer usingContext:(PTImageIODataReadContext *)readContext error:(NSError **)outError;

// cleanups manager associated with provided ID
+ (void)cleanupManagerAssociatedWithID:(NSString *)idToCleanupManagerFor;

+ (void)performCleanupBeforeAppTermination;


+ (BOOL)readPreviewImageUsingContext:(PTImageIODataReadContext *)readContext error:(NSError **)outError;
+ (BOOL)writePreviewImage:(CGImageRef)imageToWrite properties:(NSDictionary *)imageProperties usingContext:(PTImageIODataWriteContext *)writeContext error:(NSError **)outError;
+ (BOOL)readFileUsingContext:(PTImageIODataReadContext *)readContext andWriteUsingContext:(PTImageIODataWriteContext *)writeContext error:(NSError **)outError;


- (id)cacheForLayerWithID:(NSString *)layerID cacheType:(NSString *)cacheType dataChangeTimestamp:(NSTimeInterval)dataChangeTimestamp increaseUsageCount:(BOOL)increaseUsageCount;

// first checks if required cache alredy is available. if exists, usage count is increased
// if not, creates and returns new cache
// cache usage count is increased by 1
// isDiscardable - sets if cache should be removed, if it is the only version
- (id)createCacheForLayerWithID:(NSString *)layerID cacheType:(NSString *)cacheType dataChangeTimestamp:(NSTimeInterval)dataChangeTimestamp isDiscardable:(BOOL)isDiscardable;

- (id)createCacheForLayerWithID:(NSString *)layerID cacheType:(NSString *)cacheType dataChangeTimestamp:(NSTimeInterval)dataChangeTimestamp usingInternalManager:(PTImageIODataSaveManager *)manager isDiscardable:(BOOL)isDiscardable initContentFromURL:(NSURL *)contentSourceFile;


- (void)synchronouslyProtectedAccessToCacheInfoUsingBlock:(dispatch_block_t)accessBlock;

- (void)unprotected_removeCacheInfoForLayerID:(NSString *)layerIDstring type:(NSString *)cacheType timestamp:(NSTimeInterval)timestamp;




@end
