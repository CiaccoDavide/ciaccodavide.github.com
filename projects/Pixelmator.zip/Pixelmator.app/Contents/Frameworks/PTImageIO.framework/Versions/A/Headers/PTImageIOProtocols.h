//
//  PTImageIOProtocols.h
//  PTImageIO
//
//  Created by Rimas Mickevičius on 2013-01-03.
//  Copyright (c) 2013 Rimas Mickevičius. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
@class PTImageIODataWriteContext;
@class PTImageIODataReadContext;

//--------------------------------------------------------------------------------------------------------------------
// Data State Info Collector Protocol
//--------------------------------------------------------------------------------------------------------------------
@protocol PTImageIODataStateInfoCollectorProtocol;
typedef BOOL (^PTIMageIODataStateLayersInfoProvideBlock)(id <PTImageIODataStateInfoCollectorProtocol> dataCollector);

@protocol PTImageIODataStateInfoCollectorProtocol <NSObject>
- (NSDictionary *)requiredDocumentInfoKeysInformationDictionary;
- (NSArray *)requiredDocumentInfoKeys;
- (BOOL)customDocumentInfoKeysAreAllowed;
- (BOOL)setDocumentValue:(id)documentValue forKey:(NSString *)documentInfoKey;
//-(void)iterateOverRequiredDocumentKeysUsingBlock:(PTImageIODataSaveStateSnapshotRequiredValuesIteratorBlock)iteratorBlock;
- (BOOL)requiresLayersInformation;
- (NSDictionary *)requiredLayerInfoKeysInformationDictionary;
- (NSArray *)requiredLayerInfoKeys;
- (BOOL)customLayerInfoKeysAreAllowed;
- (BOOL)beginProvidingInfoForLayerWithID:(NSString *)layerIDstring ofType:(NSString *)layerTypeUTI parentID:(NSString *)layerParentIDstring indexAtParent:(NSInteger)indexAtParent continueProvidingInfoWithBlock:(PTIMageIODataStateLayersInfoProvideBlock)infoProvideBlock;
- (BOOL)setLayerValue:(id)layerValue forKey:(NSString* )layerInfoKey;
- (BOOL)requiresPrerenderedData;
@end
//--------------------------------------------------------------------------------------------------------------------

//--------------------------------------------------------------------------------------------------------------------
// Data State Info Provider Protocol
//--------------------------------------------------------------------------------------------------------------------
#define PTImageIODataStateInfoProviderPrerenderedPreviewImageDataKey    @"PTImageIODataStateInfoProviderPrerenderedPreviewImageDataKey"
@protocol PTImageIODataStateInfoProviderProtocol <NSObject>
- (NSString *)dataProviderIDForWritingContext:(PTImageIODataWriteContext *)writeContext;
- (BOOL)populateInfoIntoDataCollector:(id <PTImageIODataStateInfoCollectorProtocol>)dataCollector context:(PTImageIODataWriteContext *)writeContext;
- (NSData *)nonCopiedDataForLayerWithID:(NSString *)layerIDstring context:(PTImageIODataWriteContext *)writeContext;
- (BOOL)providerSupportsBitmapDataCopyOnWriteProtectionForContext:(PTImageIODataWriteContext *)writeContext;
- (NSData *)nonCopiedRGBADataForPrerenderedImageOfSize:(CGSize *)renderedImageBufferSizeRef rowBytes:(NSInteger *)renderedImageBufferRowbytesRef context:(PTImageIODataWriteContext *)writeContext;
- (BOOL)providerSupportsAsynchronousPreviewDataForContext:(PTImageIODataWriteContext *)writeContext;
- (void)performCleanupDueToFinishedStateWritingForContext:(PTImageIODataWriteContext *)writeContext;
@optional
- (void)unblockUserInteractionAndContinueForContext:(PTImageIODataWriteContext *)writeContext;
- (void)finishedUsingDataOfLayerWithID:(NSString *)layerIDstring context:(PTImageIODataWriteContext *)writeContext;
@end
//--------------------------------------------------------------------------------------------------------------------



//--------------------------------------------------------------------------------------------------------------------
// File Data Info Provider Protocol
//--------------------------------------------------------------------------------------------------------------------
@protocol PTImageIOFileDataInfoProviderProtocol;
typedef BOOL (^PTIMageIOFileDataAvailableDocumentKeysProviderBlock)(NSString *documentKey, id documentValue);
typedef BOOL (^PTImageIOFileLayersIterationBlock)(NSString *layerID, NSString *layerType, NSString *layerParentID, NSInteger layerIndexAtParent, id <PTImageIOFileDataInfoProviderProtocol> additionalLayerInfoprovider);
typedef BOOL (^PTIMageIOFileDataAdditionalLayerInfoProviderBlock)(NSString *layerInfoKey, id layerValue);

@protocol PTImageIOFileDataInfoProviderProtocol <NSObject>
- (NSArray *)allAvailableDocumentInfoKeys;
- (void)enumerateAvailableDocumentInfo:(PTIMageIOFileDataAvailableDocumentKeysProviderBlock)infoProviderBlock;
- (id)documentValueForKey:(NSString *)documentInfoKey;

- (BOOL)providesLayerInformation;
- (BOOL)enumerateLayersUsingBlock:(PTImageIOFileLayersIterationBlock)addLayerBlock;
- (NSArray *)availableAdditionalLayerInfoKeysForCurrentLayer;
- (BOOL)enumerateAdditionalLayerInfoUsingBlock:(PTIMageIOFileDataAdditionalLayerInfoProviderBlock)additionalInfoProvideBlock;
- (id)additionalLayerValueForKey:(NSString *)additionalLayerInfoKey;

@end
//--------------------------------------------------------------------------------------------------------------------


//--------------------------------------------------------------------------------------------------------------------
// File Data Open Info Consumer
//--------------------------------------------------------------------------------------------------------------------
@protocol PTImageIOFileDataOpenInfoConsumer <NSObject>
- (NSString *)dataConsumerID;
- (BOOL)readDocumentInfoFrom:(id <PTImageIOFileDataInfoProviderProtocol>)fileInfoDataProvider context:(PTImageIODataReadContext *)readContext error:(NSError **)outError;

- (BOOL)needsLayerBitmapData;
- (BOOL)needsPrerenderedImageBitmapData;
- (unsigned char *)preparedBufferForLayerWithID:(NSString *)layerIDstring bufferLength:(size_t *)bufferLengthRef;
- (unsigned char *)preparedPreviewImageBufferOfSize:(CGSize)previewImageSize previewBufferRowBytes:(size_t *)previewImageBufferRowBytesRef;
@end
//--------------------------------------------------------------------------------------------------------------------


