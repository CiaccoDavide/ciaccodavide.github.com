//
//  PTTypes.h
//  PTImageIO
//
//  Created by Rimas Mickevičius on 2013-01-30.
//  Copyright (c) 2013 Rimas Mickevičius. All rights reserved.
//

#ifndef OpenSaveDemo_PTTypes_h
#define OpenSaveDemo_PTTypes_h

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>

#ifdef __APPLE__
    #include "TargetConditionals.h"

    #ifndef PT_TARGET_OSX
        #define PT_TARGET_DESKTOP_CPU   (defined(__x86_64__) || defined(__i386__) || defined(__ppc64__) || defined(__ppc__))
        #define PT_TARGET_MOBILE_CPU    (defined(__arm__))
        #define PT_TARGET_IOS_DEVICE    (TARGET_OS_IPHONE && PT_TARGET_MOBILE_CPU)
        #define PT_TARGET_IOS_SIMULATOR (TARGET_IPHONE_SIMULATOR && PT_TARGET_DESKTOP_CPU && !PT_TARGET_MOBILE_CPU)
        #define PT_TARGET_IOS           (PT_TARGET_IOS_DEVICE || PT_TARGET_IOS_SIMULATOR)
        #define PT_TARGET_OSX           (TARGET_OS_MAC && PT_TARGET_DESKTOP_CPU && !PT_TARGET_IOS)
    #endif

#endif

#if PT_TARGET_OSX
    #import <AppKit/NSDocument.h>
#elif PT_TARGET_IOS
    #import <UIKit/UIGeometry.h>
    #import <UIKit/UIDocument.h>
#endif

// floating point number
typedef CGFloat PTFloat;

// point
typedef CGPoint PTPoint;
NS_INLINE PTPoint PTPointMake(PTFloat x, PTFloat y)
{
    return CGPointMake(x, y);
}

// size
typedef CGSize  PTSize;

NS_INLINE PTSize PTSizeMake(PTFloat width, PTFloat height)
{
    return CGSizeMake(width, height);
}

// rect
typedef CGRect  PTRect;
NS_INLINE PTRect PTRectMake(PTFloat x, PTFloat y, PTFloat width, PTFloat height)
{
    return CGRectMake(x, y, width, height);
}

NS_INLINE NSString* NSStringFromPTPoint(PTPoint point)
{
    #if PT_TARGET_OSX
        return NSStringFromPoint(NSPointFromCGPoint(point));
    #elif PT_TARGET_IOS
        return NSStringFromCGPoint(point);
    #else
        return [NSString stringWithFormat:@"UNDEFINED PLATFORM STRING FROM POINT: (%f;%f)", point.x, point.y];
    #endif
}

NS_INLINE PTPoint PTPointFromString(NSString* pointString)
{
    #if PT_TARGET_OSX
        return NSPointToCGPoint(NSPointFromString(pointString));
    #elif PT_TARGET_IOS
        return CGPointFromString(pointString);
    #else
        NSAssert(NO, @"Undefined platform");
        return CGPointZero;
    #endif
}

NS_INLINE NSString* NSStringFromPTSize(PTSize size)
{
    #if PT_TARGET_OSX
        return NSStringFromSize(NSSizeFromCGSize(size));
    #elif PT_TARGET_IOS
        return NSStringFromCGSize(size);
    #else
        return [NSString stringWithFormat:@"UNDEFINED PLATFORM STRING FROM SIZE: (%f;%f)", size.width, size.height];
    #endif
}

NS_INLINE PTSize PTSizeFromString(NSString* sizeString)
{
    #if PT_TARGET_OSX
        return NSSizeToCGSize(NSSizeFromString(sizeString));
    #elif PT_TARGET_IOS
        return CGSizeFromString(sizeString);
    #else
        NSAssert(NO, @"Undefined platform");
        return CGSizeZero;
    #endif
}

NS_INLINE NSString* NSStringFromPTRect(PTRect rect)
{
    #if PT_TARGET_OSX
        return NSStringFromRect(NSRectFromCGRect(rect));
    #elif PT_TARGET_IOS
        return NSStringFromCGRect(rect);
    #else
        return [NSString stringWithFormat:@"UNDEFINED PLATFORM STRING FROM RECT: (%f;%f;%f;%f)", rect.origin.x, rect.origin.y, rect.size.width, rect.size.height];
    #endif
}

// floating points comparison
#define PTFloatsComparisonDefaultEpsilon            0.001
#define PTEqualFloatsWithEpsilon(f1, f2, epsilon)   ( fabs( (f1) - (f2) ) < epsilon )
#define PTEqualFloats(f1, f2)                       ( PTEqualFloatsWithEpsilon(f1, f2, PTFloatsComparisonDefaultEpsilon) )

#ifndef PTAlignRowBytes
    #define PTAlignRowBytes(a) (((size_t)(a) + 63) & ~63)
#endif

#ifndef PTSaveOperation
    #if PT_TARGET_OSX
        typedef NSSaveOperationType PTSaveOperation;
    #elif PT_TARGET_IOS
        typedef UIDocumentSaveOperation PTSaveOperation;
    #endif
    #define PTSaveUndefinedOperation 998877
#endif

// multi-byte pixel reading and writing operations
#define PTPixelRead(pointer, bitsPerComponent) ((bitsPerComponent) == 16 ? *(uint16_t *)(pointer) : *(uint8_t *)(pointer))

// reads and writes a value of correct size from the fromPointer to the toPointer
#define PTPixelWrite(toPointer, fromPointer, bitsPerComponent)\
if ((bitsPerComponent) == 8) { *(uint8_t *)(toPointer) = *(uint8_t *)(fromPointer); }\
else if ((bitsPerComponent) == 16) { *(uint16_t *)(toPointer) = *(uint16_t *)(fromPointer); }

// writes a value of correct size from the fromValue to the toPointer
#define PTPixelWriteValue(toPointer, fromValue, bitsPerComponent)\
if ((bitsPerComponent) == 8) { *(uint8_t *)(toPointer) = (uint8_t)(fromValue); }\
else if ((bitsPerComponent) == 16) { *(uint16_t *)(toPointer) = (uint16_t)(fromValue); }

#define PTPixelChannelMax(bitsPerComponent) ((bitsPerComponent) == 8 ? UINT8_MAX : UINT16_MAX)

#endif
