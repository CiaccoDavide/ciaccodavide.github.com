//
//  PTVersionComparator.h
//  Pixelmator
//
//  Created by Rimas Mickevičius on 2013-07-04.
//  Copyright (c) 2013 Pixelmator Team Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PTVersionComparator : NSObject

+ (PTVersionComparator *)defaultComparator;
- (NSComparisonResult)compareVersion:(NSString *)versionA toVersion:(NSString *)versionB;

@end
