//
//  PTImageIOUtilities.h
//  OpenSaveDemo
//
//  Created by Rimas Mickevičius on 2013-01-03.
//  Copyright (c) 2013 Rimas Mickevičius. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Accelerate/Accelerate.h>

#import "PTTypes.h"

enum {
    PTImageIOSizeFitAlwaysOption = 1,
    PTImageIOSizeFitDownOnlyOption,
    PTImageIOSizeFitDefaultOption = PTImageIOSizeFitAlwaysOption,
};
typedef NSInteger PTImageIOSizeFitOptions;

@interface PTImageIOUtilities : NSObject

NSString* NSStringFromPTSaveOperation(PTSaveOperation saveOperation);

+ (NSString *)generalUUIDAppendingDate:(BOOL)appendDate;
+ (NSString *)generalUUIDWithPrefix:(NSString *)prefixString;

+ (BOOL)isObjectClassSupportedAsValue:(id)objectToCheck;

+ (PTSize)fitSize:(PTSize)sizeToFit intoSize:(PTSize)sizeFitInto;
+ (PTSize)fitSize:(PTSize)sizeToFit intoSize:(PTSize)sizeFitInto options:(PTImageIOSizeFitOptions)fitOptions;

+ (BOOL)imageHasTransparencyInData:(NSData *)imageData ofSize:(CGSize)imageSize rowBytes:(NSInteger)rowBytes alphaIndex:(uint8_t)alphaIndex bitsPerComponent:(uint8_t)bitsPerComponent;
+ (BOOL)imageHasTransparencyInVImageBuffer:(vImage_Buffer)imageVbuffer alphaIndex:(uint8_t)alphaIndex bitsPerComponent:(uint8_t)bitsPerComponent;

+ (CGRect)transparencyTrimmedRectInvImageBuffer:(vImage_Buffer *)imageBufferRef limitingRect:(CGRect)limitingRect alphaIndex:(uint8_t)alphaIndex bytesPerPixel:(uint8_t)bytesPerPixel numberOfComponents:(uint8_t)numberOfComponents;

// returns file, located at fileLocationURL, filesize in bytes. If this is beeing called from NSDocument, please provide it in document param.
+ (NSUInteger)fileSizeAtURL:(NSURL *)fileLocationURL callingFromDocument:(id <NSFilePresenter>)document;

+ (NSDictionary *)basicMetadataForFileAtURL:(NSURL *)fileURL fileType:(NSString *)fileType;

+ (BOOL)isFileAtURLBinaryPXM:(NSURL *)fileURL;
+ (BOOL)isFileAtURLPXM2:(NSURL *)fileURL;
+ (BOOL)isFileAtURLPXM16x:(NSURL *)fileURL;

+ (NSString *)typeUTIForFileAtURL:(NSURL *)fileURL;

#pragma - OS X versions -

+ (BOOL)isLionOrLater;
+ (BOOL)isMountainLionOrLater;
+ (BOOL)isMavericksOrLater;

@end
