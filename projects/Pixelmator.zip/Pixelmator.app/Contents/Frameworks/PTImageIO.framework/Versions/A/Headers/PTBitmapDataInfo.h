//
//  PTBitmapDataInfo.h
//  PTImageIO
//
//  Created by Rimas Mickevičius on 2013-08-29.
//
//

#import <Foundation/Foundation.h>

//                    +- for future use
//                    |
//                    |                                      +- data components ordering info
//                    |                                      |
//                    |                                      |               +- data uses float values if (format & kPTBitmapDataFormatUsesFloatComponents) != 0
//                    |                                      |               |
// +------------------+------------------+             +-----+-----+        ++-+
// |                                     |             |           |        |  |
// +--+--+--+--+--+--+--+--+ +--+--+--+--+--+--+--+--+ +--+--+--+--+--+--+--+--+ +--+--+--+--+--+--+--+--+
// |31|30|29|28|27|26|25|24| |23|22|21|20|19|18|17|16| |15|14|13|12|11|10|09|08| |07|06|05|04|03|02|01|00|
// +--+--+--+--+--+--+--+--+ +--+--+--+--+--+--+--+--+ +--+--+--+--+--+--+--+--+ +--+--+--+--+--+--+--+--+
//                                       |           |             |        |    |                       |
//                                       +-----+-----+             +---+----+    +-----------+-----------+
//                                             |                       |                     |
//                                             |                       |                     +- bits per component value = (format & kPTBitmapDataFormatBitsPerComponentInfoMask)
//                                             |                       |
//                                             |                       +- format endian info. Tells how to interpret data values when bits per component > 8. Basic formats does not include endian info = you need to set it by yourself
//                                             |
//                                             +- number of components value (0-15) shifted by 16 bits


enum {
    kPTBitmapDataUndefinedEndian  = (0 << 9),
    kPTBitmapDataLittleEndian     = (1 << 9),
    kPTBitmapDataBigEndian        = (2 << 9),
};
typedef uint32_t PTBitmapDataEndian;

enum {
    kPTBitmapDataOrdering_Undefined                 = (0 << 12),
    kPTBitmapDataOrdering_BGRA                      = (1 << 12),
    kPTBitmapDataOrdering_RGBA                      = (2 << 12),
};
typedef uint32_t PTBitmapDataComponentsOrdering;

enum {
    
    kPTBitmapDataFormatBitsPerComponentInfoMask     = 0xFF,     // no shift
    
    kPTBitmapDataFormatUsesFloatComponents          = (1 << 8),
    
    kPTBitmapDataFormatEndianInfoMask               = 0xE00,    // 9 shift
    
    kPTBitmapDataFormatOrderingInfoMask             = 0xF000,   // 12 shift
    
    kPTBitmapDataFormatNumberOfComponentsInfoMask   = 0xF0000,  // 16 shift
    
    kPTBitmapDataFormatWithoutEndianInfoMask        = 0xFFFFF1FF,
    
    kPTBitmapDataFormat_Undefined                   = 0,
    kPTBitmapDataFormat_UInt8_BGRA                  = (4 << 16 |  8 | kPTBitmapDataOrdering_BGRA),
    kPTBitmapDataFormat_UInt8_RGBA                  = (4 << 16 |  8 | kPTBitmapDataOrdering_RGBA),
    kPTBitmapDataFormat_UInt16_BGRA                 = (4 << 16 | 16 | kPTBitmapDataOrdering_BGRA),
    kPTBitmapDataFormat_UInt16_RGBA                 = (4 << 16 | 16 | kPTBitmapDataOrdering_RGBA),
    kPTBitmapDataFormat_Float16_BGRA                = (4 << 16 | 16 | kPTBitmapDataOrdering_BGRA | kPTBitmapDataFormatUsesFloatComponents),
    kPTBitmapDataFormat_Float16_RGBA                = (4 << 16 | 16 | kPTBitmapDataOrdering_RGBA | kPTBitmapDataFormatUsesFloatComponents),
    kPTBitmapDataFormat_Float32_BGRA                = (4 << 16 | 32 | kPTBitmapDataOrdering_BGRA | kPTBitmapDataFormatUsesFloatComponents),
    kPTBitmapDataFormat_Float32_RGBA                = (4 << 16 | 32 | kPTBitmapDataOrdering_RGBA | kPTBitmapDataFormatUsesFloatComponents),
};
typedef uint32_t PTBitmapDataFormat;


typedef struct {
    uint32_t            width;
    uint32_t            height;
    uint32_t            rowbytes;   // ((numberOfComponents * bitsPerComponent) / 8) * width + optional align
    PTBitmapDataFormat  dataFormat;
    void                *data;
} PTBitmapDataBuffer;

/**
 * returns bits count used to store one component data
 */
uint8_t PTBitmapDataFormatGetBitsPerComponent(PTBitmapDataFormat format);

/**
 * returns bytes count used to store one pixel data
 */
uint8_t PTBitmapDataFormatGetBytesPerPixel(PTBitmapDataFormat format);

/**
 * returns if format uses float values to store data
 */
 BOOL PTBitmapDataFormatUsesFloatValues(PTBitmapDataFormat format);

/**
 * returns number of components
 */
uint8_t PTBitmapDataFormatGetNumberOfComponents(PTBitmapDataFormat format);

/**
 * returns format data endian
 */
PTBitmapDataEndian PTBitmapDataFormatGetEndiant(PTBitmapDataFormat format);

/**
 * returns system endian
 */
PTBitmapDataEndian PTBitmapDataSystemEndian();

/**
 * returns format data components ordering
 */
PTBitmapDataComponentsOrdering PTBitmapDataFormatGetOrdering(PTBitmapDataFormat format);

/**
 * Returns the index of the alpha component in the pixel.
 */
uint8_t PTBitmapDataFormatGetAlphaIndex(PTBitmapDataFormat format);

PTBitmapDataFormat PTBitmapDataFormatWithoutEndianInfo(PTBitmapDataFormat format);

PTBitmapDataFormat PTBitmapDataFormatConstruct(uint8_t numberOfComponents, uint8_t bitsPerComponent, PTBitmapDataComponentsOrdering componentsOrdering, BOOL usesFLoats, PTBitmapDataEndian endian);

PTBitmapDataFormat PTBitmapDataFormatBySettingEndian(PTBitmapDataFormat format, PTBitmapDataEndian newEndian);

PTBitmapDataFormat PTBitmapDataFormatBySettingBitsPerComponents(PTBitmapDataFormat format, uint8_t newBitsPerComponentValue);

size_t PTBitmapDataBufferRowBytesForWidthUsingFormat(size_t bufferWidth, PTBitmapDataFormat format, BOOL shouldAlign);

void PTBitmapDataFormatPrintInfo(PTBitmapDataFormat format, NSString *title);

@interface PTBitmapDataInfo : NSObject

+ (void)runTest;

@end
