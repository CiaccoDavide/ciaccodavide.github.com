//
//  PTImageIODefinitions.h
//  PTImageIO
//
//  Created by Rimas Mickevičius on 2013-01-03.
//  Copyright (c) 2013 Rimas Mickevičius. All rights reserved.
//

#ifndef OpenSaveDemo_PTImageIODefinitions_h
#define OpenSaveDemo_PTImageIODefinitions_h

#include "PTTypes.h"

#define PTImageIOBinaryDocumentExtension    @"pxm"
#define PTImageIOPackageDocumentExtension   @"pxm" // pxd

//#define PTImageIOLegacyDocumentTypeUTI    @"com.pixelmator.pxm"
#define PTImageIOBinaryDocumentTypeUTI      @"com.pixelmator.pxm" //PTImageIOLegacyDocumentTypeUTI  //@"com.pixelmatorteam.pixelmator.document"
#define PTImageIOPackageDocumentTypeUTI     @"com.pixelmatorteam.pixelmator.document-package"
#define PTImageIOPhotoshopDocumentTypeUTI   @"com.adobe.photoshop-image"
#define PTImageIOPDFDocumentTypeUTI         (NSString *)kUTTypePDF
#define PTImageIORAWDocumentTypeUTI         @"public.camera-raw-image"
#define PTImageIOWebPDocumentTypeUTI        @"public.webp"
#define PTImageIOTIFFDocumentTypeUTI        (NSString *)kUTTypeTIFF
#define PTImageIOPNGDocumentTypeUTI         (NSString *)kUTTypePNG
#define PTImageIOTGADocumentTypeUTI         @"com.truevision.tga-image"
#define PTImageIOJPEG2000DocumentTypeUTI    (NSString *)kUTTypeJPEG2000
#define PTImageIOJPEGDocumentTypeUTI        (NSString *)kUTTypeJPEG
#define PTImageIOBMPDocumentTypeUTI         (NSString *)kUTTypeBMP

#define PTImageIO_PXM_DocumentInfo_FileName     @"document/info"
#define PTImageIO_PXM_DocumentMeta_FileName     @"document/meta"
#define PTImageIO_PXM_Preview_FileName          @"QuickLook/Preview.tiff"
#define PTImageIO_PXM_Thumbnail_FileName        @"QuickLook/Thumbnail.tiff"
#define PTImageIO_PXM_MetaSignature             @"PXMDMETA"

#define LEGACY_PXM2_HEADER_LENGTH 14

#define PTIIOPrintCurrentFunction PTImageIOLog(@"%s", __FUNCTION__);

#define PTImageIOErrorDomain    @"PTImageIOErrorDomain"

enum {
    PTImageIOUndefinedResolutionUnit = 0,
    PTImageIOPixelsPerInchResolutionUnit = 1,
    PTImageIOPixelsPerCentimeterResolutionUnit = 2,
};
typedef NSInteger PTImageIOResolutionUnits;

enum {
    // no error
    PTImageIONoErrorCode                        = 0,
    
    // generic errors
    PTImageIOUnknownErrorCode                   = 100,
    PTImageIOCanNotGetManagerErrorCode,
    PTImageIOCanNotCreateManagerErrorCode,
    PTImageIOFormatIsNotSupportedErrorCode,
    PTImageIOManagerDoesNotHaveCacheFolderPath,
    
    // write errors
    PTImageIOGenericWriteErrorCode              = 1000,
    PTIMageIONoDataProviderErrorCode,
    PTIMageIONoWriteContextErrorCode,
    PTImageIOCanNotCreateSnapshotErrorCode,
    PTImageIOCanNotPopulateDataErrorCode,
    PTImageIOCanNotGatherBitmapDataErrorCode,
    PTImageIOCanNotWriteSnapshotErrorCode,
    PTIMageIONoCacheDirectoryErrorCode,
    PTImageIOCanNotGetLayerBitmapDataErrorCode,
    PTImageIOCanNotCreateResultFileErrorCode,
    PTImageIOCanNotCreateDocumentInfoFileErrorCode,
    PTImageIOCanNotReadDocumentInfoFileErrorCode,
    PTImageIOCanNotCreateLocalFileHeaderDataErrorCode,
    PTImageIOCanNotCreateCentralDirectoryFileHeaderDataErrorCode,
    PTImageIOCanNotWriteToZipOutputStreamErrorCode,
    PTImageIOCanNotCreateZipWriteOutputFileAsscessQueueErrorCode,
    PTImageIOCanNotCreateZipWriteDispatchGroupErrorCode,
    PTImageIOCanNotCreateZipWriteErrorAccessQueueErrorCode,
    PTImageIOCanNotGetPrerenderedImageDataErrorCode,
    PTImageIOCanNotCreatePrerenderedDataCacheErrorCode,
    PTImageIOCanNotWritePrerenderedImageDataErrorCode,
    PTImageIOCanNotWriteThumbnailImageDataErrorCode,
    PTImageIOMemoryAllocationWhileWritingErrorCode,                   // problema allocuojant atminti.
    PTImageIOCanNotReadCompressedDataCacheErrorCode,
    PTImageIOCacheNotFoundErrorCode,
    PTImageIOCanNotCreateCompressedDataCacheErrorCode,
    PTImageIOCanNotCreateRawDataCacheErrorCode,
    PTImageIOCanNotWriteToCompresseddataCacheErrorCode,
    PTImageIOCanNotWriteToRawDataCacheErrorCode,
    PTImageIOCanNotCreateDispatchDataErrorCode,
    PTImageIOCanNotGetCompressorErrorCode,
    PTImageIOCanNotCompressDispatchdataErrorCode,
    PTImageIOCanNotCompressDataErrorCode,
    PTImageIOCanNotSetValueForDataCacheErrorCode,
    PTImageIOCanNotCreateCentralDirectoryEndRecordDataErrorCode,
    PTImageIOCanNotCreateOutputPackageDirectoryErrorCode,
    PTImageIOCanNotCreateInternalPackageDirectoryErrorCode,
    PTImageIOCanNotWriteToOutputPackageErrorCode,
    PTImageIOCanNotCreatePackageProcessingQueueErrorCode,
    PTImageIOCanNotCreatePackageWriteDispatchGroupErrorCode,
    PTImageIOCanNotCreatePackageWriteErrorAccessQueueErrorCode,
    PTImageIOCanNotCopyCacheToDestinationErrorCode,
    PTImageIODataStateSnapshotInvalidErrorCode,
    PTImageIOCanNotGetColorProfileErrorCode,
    PTImageIOCanNotCreateDataProviderErrorCode,
    PTImageIOCanNotCreatePrerenderedImageErrorCode,
    PTImageIOCanNotCreatePrerenderedImageDestinationErrorCode,
    PTImageIOCanNotCreateWebPImageDataErrorCode,
    PTImageIOLastWritingErrorCode, // << this must be the last one for reading errors, because it is beeing used to determine error codes range
    
    // read errors
    PTImageIOGenericReadErrorCode                       = 2000,
    PTImageIOCanNotValidateInputFile,
    PTImageIOCanNotCopyDocumentInfo,
    PTImageIOFileNotFoundErrorCode,
    PTImageIOImageSourceCanNotBeCreatedErrorCode,
    PTImageIONoImagesInSourceErrorCode,
    PTImageIOCanNotGetImageErrorCode,
    PTImageIOInvalidImageSizeErrorCode,
    PTImageIOMemoryAllocationWhileReadingErrorCode,
    PTImageIOCanNotCreateDrawContextErrorCode,
    PTImageIOCanNotCreateCGImageErrorCode,
    PTImageIOAppVersionIsTooOldForFileErrorCode,
    PTImageIOCanNotCreatePDFDocumentErrorCode,
    PTImageIONoPagesInPDFErrorCode,
    PTImageIOCanNotGetPDFPageErrorCode,
    PTImageIOBadMediaBoxRectErrorCode,
    PTImageIOCanNotGetColorSpaceErrorCode,
    PTImageIOCanNptReadSourceDataErrorCode,
    PTImageIOCanNotParseWebPImageDataErrorCode,
    PTImageIODataIntegrityReadingErrorCode,
    PTImageIOCanNotReadDataFromFileErrorCode,
    PTImageIOCanNotDecompressDataErrorCode,
    PTImageIOCanNotReadPreviewImageErrorCode,
    PTImageIOFileHasToManyLayersErrorCode,
    PTImageIOBitsPerComponentValueNotSupportedReadingErrorCode,
    PTImageIOLastReadingErrorCode, // << this must be the last one for reading errors, because it is beeing used to determine error codes range
    
    // iCloud errors
    PTImageIOErrorCodeDownloadFromCloudFailed   = 3000,
    PTImageIOErrorCodeDownloadFromCloudTimeout,
    
    // Automator
    PTImageIOAutomatorFailedToRewriteFileErrorCode = 4000,
    
    PTImageIOTheLastErrorCode,
};

#define PXOSF_ErrorUserInfoKey_MinimumRequiredAppVersionToOpen  @"PXOSF_ErrorUserInfoKey_MinimumRequiredAppVersionToOpen"
#define PXOSF_ErrorUserInfoKey_CurrentAppVersion                @"PXOSF_ErrorUserInfoKey_CurrentAppVersion"
#define PXOSF_ErrorUserInfoKey_SavePlatform                     @"PXOSF_ErrorUserInfoKey_SavePlatform"
#define PXOSF_ErrorUserInfoKey_DocumentURL                      @"PXOSF_ErrorUserInfoKey_DocumentURL"
#define PTImageIO_ErrorUserInfoKey_BitsPerComponentValue        @"PTImageIO_ErrorUserInfoKey_BitsPerComponentValue"

enum {
    PTImageIODataManagerDefaultOptions = 0,
    PTImageIODataManagerOneActionOption = 1 << 0,
    // no cache option
    // write asynchronously option
};
typedef NSInteger PTImageIOWriteOptions;

enum {
    PTImageIOImageDataBufferFormat_BGRA = 0,
};
typedef NSInteger PTImageIOImageDataBufferFormat;


#define DEBUG_PixelmatorLayer_BITMAP @"com.pixelmatorteam.pixelmator.layer.bitmap"

enum {
    PTImageIOCacheType_BitmapLayerCompressedData = 1,
};
typedef NSInteger PTImageIOCacheType;

typedef void (^PTImageIOActivityProgressProvider)(PTFloat currentProgress);
typedef void (^PTImageIOActivityCompletionHandler)(NSError* completionErrorOrNil);

#define PTImageIOReadingProgressScaleFactor 10000.0

#if !defined(PTClamp)
    #define PTClamp(value, low, high) ({\
        __typeof__(value)   pt_defineVar_clamp_value = (value); \
        __typeof__(low)     pt_defineVar_clamp_low_value = (low);\
        __typeof__(high)    pt_defineVar_clamp_high_value = (high);\
        pt_defineVar_clamp_value > pt_defineVar_clamp_high_value ? pt_defineVar_clamp_high_value : (pt_defineVar_clamp_value < pt_defineVar_clamp_low_value ? pt_defineVar_clamp_low_value : pt_defineVar_clamp_value);\
})
#endif

#if !defined(PTMIN2)
    #define PTMIN2(A, B)    ({\
        __typeof__(A) pt_defineVar_min2_a = (A);\
        __typeof__(B) pt_defineVar_min2_b = (B);\
        pt_defineVar_min2_a < pt_defineVar_min2_b ? pt_defineVar_min2_a : pt_defineVar_min2_b; })
#endif

#if !defined(PTMAX2)
    #define PTMAX2(A, B)    ({\
        __typeof__(A) pt_defineVar_max2_a = (A);\
        __typeof__(B) pt_defineVar_max2_b = (B);\
        pt_defineVar_max2_a < pt_defineVar_max2_b ? pt_defineVar_max2_b : pt_defineVar_max2_a; })
#endif

#if !defined(PTMIN3)
    #define PTMIN3(A, B, C) ({\
        __typeof__(A) pt_defineVar_min3_a = (A);\
        __typeof__(B) pt_defineVar_min3_b = (B);\
        __typeof__(C) pt_defineVar_min3_c = (C);\
        pt_defineVar_min3_a < pt_defineVar_min3_b ? (pt_defineVar_min3_a < pt_defineVar_min3_c ? pt_defineVar_min3_a : pt_defineVar_min3_c) : (pt_defineVar_min3_b < pt_defineVar_min3_c ? pt_defineVar_min3_b : pt_defineVar_min3_c); })
#endif

#if !defined(PTMAX3)
    #define PTMAX3(A, B, C)	({\
        __typeof__(A) pt_defineVar_max3_a = (A);\
        __typeof__(B) pt_defineVar_max3_b = (B);\
        __typeof__(C) pt_defineVar_max3_c = (C);\
        pt_defineVar_max3_a < pt_defineVar_max3_b ? (pt_defineVar_max3_b < pt_defineVar_max3_c ? pt_defineVar_max3_c : pt_defineVar_max3_b) : (pt_defineVar_max3_a < pt_defineVar_max3_c ? pt_defineVar_max3_c : pt_defineVar_max3_a); })
#endif

#if !defined(PTMIN4)
    #define PTMIN4(A, B, C, D)	({\
        __typeof__(A) pt_defineVar_min4_a = (A);\
        __typeof__(B) pt_defineVar_min4_b = (B);\
        __typeof__(C) pt_defineVar_min4_c = (C);\
        __typeof__(D) pt_defineVar_min4_d = (D);\
        pt_defineVar_min4_a < pt_defineVar_min4_b ? (pt_defineVar_min4_a < pt_defineVar_min4_d ? (pt_defineVar_min4_a < pt_defineVar_min4_c ? pt_defineVar_min4_a : pt_defineVar_min4_c) : (pt_defineVar_min4_d < pt_defineVar_min4_c ? pt_defineVar_min4_d : pt_defineVar_min4_c)) : (pt_defineVar_min4_d < pt_defineVar_min4_b ? (pt_defineVar_min4_d < pt_defineVar_min4_c ? pt_defineVar_min4_d : pt_defineVar_min4_c) : (pt_defineVar_min4_b < pt_defineVar_min4_c ? pt_defineVar_min4_b : pt_defineVar_min4_c)); })
#endif

#if !defined(PTMAX4)
    #define PTMAX4(A, B, C, D)	({\
        __typeof__(A) pt_defineVar_max4_a = (A);\
        __typeof__(B) pt_defineVar_max4_b = (B);\
        __typeof__(C) pt_defineVar_max4_c = (C);\
        __typeof__(D) pt_defineVar_max4_d = (D);\
        pt_defineVar_max4_a < pt_defineVar_max4_b ? (pt_defineVar_max4_d < pt_defineVar_max4_b ? (pt_defineVar_max4_b < pt_defineVar_max4_c ? pt_defineVar_max4_c : pt_defineVar_max4_b) : (pt_defineVar_max4_d < pt_defineVar_max4_c ? pt_defineVar_max4_c : pt_defineVar_max4_d)) : (pt_defineVar_max4_a < pt_defineVar_max4_d ? (pt_defineVar_max4_d < pt_defineVar_max4_c ? pt_defineVar_max4_c : pt_defineVar_max4_d) : (pt_defineVar_max4_a < pt_defineVar_max4_c ? pt_defineVar_max4_c : pt_defineVar_max4_a)); })
#endif

#if (!defined(PTMIN5) && defined(PTMIN4))
    #define PTMIN5(A, B, C, D, E)	({\
        __typeof__(A) pt_defineVar_min5_a = (A);\
        __typeof__(B) pt_defineVar_min5_b = (B);\
        __typeof__(C) pt_defineVar_min5_c = (C);\
        __typeof__(D) pt_defineVar_min5_d = (D);\
        __typeof__(E) pt_defineVar_min5_e = (E);\
        pt_defineVar_min5_a < pt_defineVar_min5_b ? PTMIN4(pt_defineVar_min5_a, pt_defineVar_min5_c, pt_defineVar_min5_d, pt_defineVar_min5_e) : PTMIN4(pt_defineVar_min5_b, pt_defineVar_min5_c, pt_defineVar_min5_d, pt_defineVar_min5_e); })
#endif

#if (!defined(PTMAX5) && defined(PTMAX4))
    #define PTMAX5(A, B, C, D, E)	({\
        __typeof__(A) pt_defineVar_max5_a = (A);\
        __typeof__(B) pt_defineVar_max5_b = (B);\
        __typeof__(C) pt_defineVar_max5_c = (C);\
        __typeof__(D) pt_defineVar_max5_d = (D);\
        __typeof__(E) pt_defineVar_max5_e = (E);\
        pt_defineVar_max5_a < pt_defineVar_max5_b ? PTMAX4(pt_defineVar_max5_b, pt_defineVar_max5_c, pt_defineVar_max5_d, pt_defineVar_max5_e) : PTMAX4(pt_defineVar_max5_a, pt_defineVar_max5_c, pt_defineVar_max5_d, pt_defineVar_max5_e); })
#endif

#define PTImageIOLog_Enabled 0
#if PTImageIOLog_Enabled
    #define PTImageIOLog(fmt, ...) PTImageIOLog(fmt, ## __VA_ARGS__)
#else
    #define PTImageIOLog(fmt, ...) ((void)0)
#endif

#endif
