//
//  PTImageIOSWJPEGOptimizer.h
//  PTImageIO
//
//  Created by Aidas Dailide on 2009-04-27.
//  Copyright 2009 Pixelmator Team Ltd.. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <Accelerate/Accelerate.h>

@interface PTImageIOSWJPEGOptimizer : NSObject {
	NSLock *_writeLock;
}
-(NSData *)writeJPEGBuffer:(vImage_Buffer *)imageBuffer quality:(int)quality;
@end
