//
//  PTImageIOWebPOptimizer.h
//  PTImageIO
//
//  Created by Rimas Mickevičius on 2013-07-28.
//
//

#import <Foundation/Foundation.h>

#import <Accelerate/Accelerate.h>

@interface PTImageIOWebPOptimizer : NSObject

+ (NSData *)writeWebPFromRGBABuffer:(vImage_Buffer)sourceBuffer quality:(int)quality;
//called is responsible for releasing returned vImage_Buffer->data and vImage_Buffer itself
+ (vImage_Buffer *)readRGBAFromWebPBuffer:(unsigned char *)webPData length:(int)webPLength;
+ (vImage_Buffer *)readBGRAFromWebPBuffer:(unsigned char *)webPData length:(int)webPLength;

@end
