//
//  PTImageIOZipTools.h
//  OpenSaveDemo
//
//  Created by Rimas Mickevičius on 2013-01-08.
//  Copyright (c) 2013 Rimas Mickevičius. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <zlib.h>

typedef struct {
    uint32_t signature;
    uint16_t minimumVersionNeededToExtract;
    uint16_t generalPurposeBitFlag;
    uint16_t compressionMethod;
    uint16_t fileLastModificationTime;
    uint16_t fileLastModificationDate;
    uint32_t CRC32;
    uint32_t compressedSize;
    uint32_t uncompressedSize;
    uint16_t fileNameLength;
    uint16_t extraFieldLength;
} PTImageIOZipLocalFileHeader;
static const uint32_t PTImageIOZipLocalFileHeaderSignature       = 0x04034b50;
static const uint16_t PTImageIOZipLocalFileHeaderConstantSize    = 30;
static const uint16_t PTImageIOZipLocalFileHeaderFileNameOffset  = 30;


typedef struct {
    uint32_t signature;
    uint16_t versionMadeBy;
    uint16_t versionNeededToExtract;
    uint16_t generalPurposeBitFlag;
    uint16_t compressionMethod;
    uint16_t fileLastModificationTime;
    uint16_t fileLastModificationDate;
    uint32_t CRC32;
    uint32_t compressedSize;
    uint32_t uncompressedSize;
    uint16_t fileNameLength;
    uint16_t extraFieldLength;
    uint16_t fileCommentLength;
    uint16_t diskNumberWhereFileStarts;
    uint16_t internalFileAttributes;
    uint32_t externalFileAttributes;
    uint32_t relativeOffsetOfLocalFileHeader;
} PTImageIOZipCentralDirectoryFileHeader;
static const uint32_t PTImageIOZipCentralDirectoryFileHeaderSignature       = 0x02014b50;
static const uint16_t PTImageIOZipCentralDirectoryFileHeaderConstantSize    = 46;
static const uint16_t PTImageIOZipCentralDirectoryFileHeaderFileNameOffset  = 46;


typedef struct
{
	uint32_t signature;
	uint16_t numberOfThisDisk;
	uint16_t numberOfTheDiskWithTheStartOfTheCentralDirectory;
	uint16_t totalNumberOfEntriesInTheCentralDirectoryOnThisDisk;
	uint16_t totalNumberOfEntriesInTheCentralDirectory;
	uint32_t sizeOfTheCentralDirectory;
	uint32_t offsetOfStartOfCentralDirectoryWithRespectToTheStartingDiskNumber;
	uint16_t zipFileCommentLength;
} PTImageIOZipEndOfCentralDirectory;
static const uint32_t PTImageIOZipCentralDirectoryEndSignature      = 0x06054b50;
static const uint16_t PTImageIOZipEndOfCentralDirectoryConstantSize = 22;


@interface NSData (CRC32)
- (uint32_t)CRC32Value;
@end

@interface PTImageIOZipTools : NSObject




+(NSData*)localFileHeaderDataForData:(NSData*)inputData zipFileInsideName:(NSString*)fileName appendData:(BOOL)appendData;
+(NSData*)localFileHeaderDataForDataOfSize:(size_t)dataSize withCRC32:(uLong)crc32Value timestamp:(double)timestamp zipFileInsideName:(NSString*)fileName;

+(NSData*)centralDirectoryFileHeaderDataForLocalFileHeaderData:(NSData*)localFileHeaderData localFileHeaderStartOffset:(uint32_t)inLocalFileHeaderStartOffset;

+(NSData*)endOfCentralDirectoryRecordDataForRecordsCount:(uint16_t)inNumberOfRecords centralDirectorySize:(uint32_t)inSizeOfCentralDirectory centralDirectoryStartOffset:(uint32_t)inCentralDirectoryStartOffset;



+(BOOL)findCentralDirectoryLocation:(uint32_t*)centralDirectoryStartOffsetRef numberOfCentralDirectoryRecords:(uint16_t*)numberOfCentralDirectoryRecordsRef sizeOfCentralDirectory:(uint32_t*)sizeOfCentralDirectoryRef inData:(NSData*)fileEndData;
+(NSDictionary*)collectCentralDirectoryFileHeadersInfoFromData:(NSData*)fileData dataStartingOffsetInFile:(uint32_t)dataStartingOffsetInFile numberOfRecords:(uint16_t)numberOfRecords firstRecordOffsetInFile:(uint32_t)firstRecordOffsetInFile centralDirectorySize:(uint32_t)centralDirectorySize;




+(NSDictionary*)collectZipArchiveRecordsInfoFromFileAtURL:(NSURL*)fileToReadURL;

+ (BOOL)isFileAtURLZip:(NSURL *)fileURLToCheck;
+ (NSData *)dataForFileWithName:(NSString *)internalFileName inZipArchiveAtURL:(NSURL *)zipArchiveURL;

// caller ir responsible for releasing returned image
+ (CGImageRef)imageForFileWithName:(NSString *)internalFileName inZipArchiveAtURL:(NSURL *)zipArchiveURL;

@end
